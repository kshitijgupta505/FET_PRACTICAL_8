function moj(){

    let pro = new Promise((resolve,reject) => {
        let y =prompt("Are You Sick");
        if(y == "yes"){
            resolve("Ohh no !! NO cakes for Party!")
        }
        else if(y == "no"){
            let cake = prompt("How many cakes you want")
            reject(`Yes , We can get ${cake} for Party`);
        }
    })
    
    pro.then(data => {
        alert(data);
    })
    .catch(error => {
        alert(error);
    })
    .finally(f => {
        alert("We have a party tonight");
    })

}


